/*
 * agentcell.hh
 *
 *  Created on: Jan 20, 2009
 *      Author: msneddon
 */

#ifndef AGENTCELL_HH_
#define AGENTCELL_HH_

#include <string>
#include <map>

using namespace std;
void runAgentCell(map<string,string> argMap, bool verbose);


#endif /* AGENTCELL_HH_ */
