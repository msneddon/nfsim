
***********************************************************************************

In this directory, you will find a simple coarse-grained model of the bacterial
flage

***********************************************************************************


This model is in the extended BNGL format designed for NFsim, so it currently can
only run in NFsim.  Instructions for running BioNetGen and NFsim can be found
at the NFsim website or user manual.