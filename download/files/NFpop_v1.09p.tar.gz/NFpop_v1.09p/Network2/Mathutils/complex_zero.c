/* math utility subroutines */
#include "mathutils.h"


dcomplex COMPLEX_ZERO={0.0,0.0};

