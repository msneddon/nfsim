#include "mathutils.h"

		    
/*==========================================================================*/

double Cprob(dcomplex a)
{
  return(a.r*a.r + a.i*a.i);
}
