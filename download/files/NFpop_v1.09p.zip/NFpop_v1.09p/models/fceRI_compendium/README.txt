
***********************************************************************************

In this directory, you will a compendium of large, rule-based Fce-RI models.  The
models were originally developed to study the early event of Fce-RI signaling in
the following study:

Faeder, JR, et. al. Investigation of Early Events in FcRI-Mediated Signaling Using a 
Detailed Mathematical Model. The Journal of Immunology, 2003, 170: 3769-3781.

***********************************************************************************


These models are in standard BNGL format, so can be run following the instructions
from the NFsim website or user manual.