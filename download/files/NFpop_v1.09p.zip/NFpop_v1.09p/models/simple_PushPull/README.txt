
***********************************************************************************

In this directory, you will find a simple push-pull system that is the
most basic test for NFsim, and a good introduction to both BNGL and running
models in NFsim.

***********************************************************************************



This model is in standard BNGL format, so can be run following the instructions
from the NFsim website or user manual.